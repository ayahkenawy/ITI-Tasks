backup database iti2
to disk='d:\db\iti.bak'
